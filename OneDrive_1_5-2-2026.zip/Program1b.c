#include <stdio.h>
typedef struct {
int emp_id;
char name[20];
float salary;
} Employee; // ’Employee’ is alias for struct
int main() {
Employee e1 = {1001, "Kiran", 45000.50};
printf("Employee ID: %d\n", e1.emp_id);
printf("Name: %s\n", e1.name);
printf("Salary: %.2f\n", e1.salary);
return 0; }
Output:
Employee ID: 1001
Name: Kiran
Salary: 45000.50
