include <stdio.h>
include <stdlib.h>
int main() {
int *ptr = (int *) malloc(3 * sizeof(int));
for(int i=0; i<3; i++) ptr[i] = i + 1;
ptr = (int *) realloc(ptr, 5 * sizeof(int));
for(int i=3; i<5; i++) ptr[i] = i + 1;
for(int i=0; i<5; i++) printf("%d ", ptr[i]);
free(ptr);
return 0;
}
Output:
1 2 3 4 5
